<?php

namespace App\Controller;

use App\Entity\Ticket;
use App\Form\TicketType;
use App\Repository\TicketRepository;
use App\Service\FileUploader;
use Mailjet\Client;
use Mailjet\Resources;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/")
 */
class TicketController extends AbstractController
{
    /**
     * @Route("/", name="home", methods={"GET","POST"})
     */
    public function new(Request $request, FileUploader $fileUploader): Response
    {
        $ticket = new Ticket();
        $form = $this->createForm(TicketType::class, $ticket);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $email = $request->get('mailpro') . '@' . $request->get('maildomain');
            $nom_complet = explode('.', $request->get('mailpro'));
            $prenom = ucfirst($nom_complet[0]);
            $nom = strtoupper($nom_complet[1]);
            if($ticket->getAttachment() !== null){
                $file = $ticket->getAttachment();
                $fileName = $fileUploader->upload($file);
                $ticket->setAttachment($fileName);
            }
            $ticket->setMd5(md5(uniqid()));
            $ticket->setAsker($email);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($ticket);
            $entityManager->flush();
            $mj = new Client(getenv('MAILJET_APIKEY_PUBLIC'), getenv('MAILJET_APIKEY_PRIVATE'),
                true, ['version' => 'v3.1']);
            $body_asker = [
                'Messages' => [
                    [
                        'From' => [
                            'Email' => "helpist@mgel.fr",
                            'Name' => "MGEL HELPIST"
                        ],
                        'To' => [
                            [
                                'Email' => $email,
                                'Name' => $nom . ' ' . $prenom,
                            ]
                        ],
                        'Subject' => "HELPIST - " . $ticket->getCategory()->getNom(),
                        'HTMLPart' => "<html><body><h3>Merci d'avoir utilisé HELPIST</h3>
<br>
<h5>Votre ticket à bien été enregistré, votre numéro de suivi est le suivant:</h5>
<br>
<h1>" . $ticket->getMd5() . "</h1>
<br>
<a href='http://helpist.mgel-dev.fr/ticket/" . $ticket->getMd5() . "'>
Suivre votre ticket</a>
</body>
</html>"
                    ]
                ]
            ];
            $body_souki = [
                'Messages' => [
                    [
                        'From' => [
                            'Email' => "helpist@mgel.fr",
                            'Name' => "MGEL HELPIST"
                        ],
                        'To' => [
                            [
                                'Email' => 'soukaina.laarissi@mgel.fr',
                                'Name' => 'LAARISSI Soukaïna',
                            ]
                        ],
                        'Subject' => "HELPIST - Nouveau ticket - " . $ticket->getCategory()->getNom(),
                        'HTMLPart' => "<html><body><h3>Vous avez un nouveau ticket à traiter !</h3>
<h5>Numéro de suivi</h5>
<h1>" . $ticket->getMd5() . "</h1>
<br>
<h5>Categorie:</h5>
<h5>". $ticket->getCategory()->getNom()."</h5>
<a href='http://helpist.mgel-dev.fr/admin/ticket/" . $ticket->getMd5() . "'>
Voir le ticket</a>
</body>
</html>"
                    ]
                ]
            ];
            $response_asker = $mj->post(Resources::$Email, ['body' => $body_asker]);
            $response_asker->success();
            $response_souki = $mj->post(Resources::$Email, ['body' => $body_souki]);
            $response_souki->success();
            return $this->redirectToRoute('home');
        }

        return $this->render('ticket/new.html.twig', [
            'ticket' => $ticket,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/ticket/{md5}", name="ticket_show_user", methods={"GET"})
     */
    public function show(TicketRepository $ticketRepository, $md5): Response
    {
        return $this->render('ticket/show.html.twig', [
            'ticket' => $ticketRepository->findOneBy(['md5' => $md5]),
        ]);
    }

}
