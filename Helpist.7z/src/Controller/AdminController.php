<?php

namespace App\Controller;

use App\Entity\Category;
use App\Entity\Ticket;
use App\Form\CategoryType;
use App\Repository\CategoryRepository;
use App\Repository\TicketRepository;
use Mailjet\Client;
use Mailjet\Resources;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * @Route("/admin")
 */
class AdminController extends AbstractController
{

    /**
     * @Route("/", name="ticket_index", methods={"GET","POST"})
     */
    public function list(Request $request,TicketRepository $ticketRepository,CategoryRepository $categoryRepository): Response
    {
        $category = new Category();
        $form = $this->createForm(CategoryType::class, $category);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($category);
            $entityManager->flush();

            return $this->redirectToRoute('ticket_index');
        }
        return $this->render('ticket/index.html.twig', [
            'categories' => $categoryRepository->findAlls(),
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/ticket/old", name="ticket_old", methods={"GET","POST"})
     */
    public function listOld(TicketRepository $ticketRepository,CategoryRepository $categoryRepository): Response
    {
        return $this->render('ticket/index.html.twig', [
            'categories' => $categoryRepository->findOlds(),
        ]);
    }

    /**
     * @Route("/ticket/{md5}", name="ticket_show", methods={"GET"})
     */
    public function show(TicketRepository $ticketRepository,$md5): Response
    {
        return $this->render('ticket/show.html.twig', [
            'ticket' => $ticketRepository->findOneBy(['md5'=>$md5]),
        ]);
    }

    /**
     * @Route("/ticket/{md5}/close", name="ticket_close", methods={"GET"})
     */
    public function close(TicketRepository $ticketRepository,$md5): Response
    {
        $em = $this->getDoctrine()->getManager();
        $ticket = $ticketRepository->findOneBy(['md5'=>$md5]);
        $ticket->setProcessedBy($this->getUser());
        $ticket->setStatus(1);
        $ticket->setCloseDate(new \DateTime('now'));
        $em->persist($ticket);
        $em->flush();
        $mail = explode('@', $ticket->getAsker());
        $nom_complet = explode('.',$mail[0]);
        $prenom = ucfirst($nom_complet[0]);
        $nom = strtoupper($nom_complet[1]);
        $mj = new Client(getenv('MAILJET_APIKEY_PUBLIC'), getenv('MAILJET_APIKEY_PRIVATE'),
            true, ['version' => 'v3.1']);
        $body_asker = [
            'Messages' => [
                [
                    'From' => [
                        'Email' => "helpist@mgel.fr",
                        'Name' => "MGEL HELPIST"
                    ],
                    'To' => [
                        [
                            'Email' => $ticket->getAsker(),
                            'Name' => $nom . ' ' . $prenom,
                        ]
                    ],
                    'Subject' => "HELPIST - " . $ticket->getCategory()->getNom(),
                    'HTMLPart' => "<html><body><h3>Votre ticket à été traité !</h3>
<br>
<h5>Votre ticket à bien été traité, votre numéro de suivi est le suivant:</h5>
<br>
<h1>" . $ticket->getMd5() . "</h1>
<br>
<a href='http://helpist.dev.mgel/ticket/" . $ticket->getMd5() . "'>
Visualiser le ticket</a>
</body>
</html>"
                ]
            ]
        ];
        $response_asker = $mj->post(Resources::$Email, ['body' => $body_asker]);
        $response_asker->success();
        return $this->redirectToRoute('ticket_index');
    }

    /**
     * @Route("/ticket/{id}/edit", name="ticket_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Ticket $ticket): Response
    {
        $form = $this->createForm(TicketType::class, $ticket);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('ticket_index', [
                'id' => $ticket->getId(),
            ]);
        }

        return $this->render('ticket/edit.html.twig', [
            'ticket' => $ticket,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/ticket/{id}", name="ticket_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Ticket $ticket): Response
    {
        if ($this->isCsrfTokenValid('delete'.$ticket->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($ticket);
            $entityManager->flush();
        }

        return $this->redirectToRoute('ticket_index');
    }
}
